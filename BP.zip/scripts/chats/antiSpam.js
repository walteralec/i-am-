const COOLDOWN_MS = 1500; 
const playerCooldowns = new Map();

export const AntiSpam = {
    isSpamming(playerName) {
        const now = Date.now();
        if (now - (playerCooldowns.get(playerName) || 0) < COOLDOWN_MS) return true;
        playerCooldowns.set(playerName, now);
        return false;
    },
    clearPlayer(playerName) {
        playerCooldowns.delete(playerName);
    }
};