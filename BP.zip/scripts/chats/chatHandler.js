import { world } from "@minecraft/server";

export function setupChatHandler() {
    world.beforeEvents.chatSend.subscribe((eventData) => {
        const player = eventData.sender;
        const message = eventData.message;
        
        // Buscamos el tag del clan (ej: "clan:DragonSlayers")
        const clanTag = player.getTags().find(t => t.startsWith("clan:"));
        const clanName = clanTag ? clanTag.replace("clan:", "") : null;

        // Formateamos el mensaje
        const prefix = clanName ? `§7[§e${clanName}§7] §f` : "";
        const formattedMessage = `${prefix}${player.name}: ${message}`;

        // Cancelamos el mensaje original y enviamos el nuevo
        eventData.cancel = true;
        world.sendMessage(formattedMessage);
    });
}