import { world, system } from "@minecraft/server";
import { AntiSpam } from "./antiSpam.js";
import { ClanManager } from "../clans/clanManager.js";
import { ClanInvites } from "../clans/clanInvites.js";
import { ClanChat } from "./clanChat.js";
import { PrivateChat } from "./privateChat.js";
import { TeamManager } from "../teams/teamManager.js";
import { showMainClanMenu } from "../ui/clanForms.js"; // Usamos el PRO

// Usamos BEFORE events para poder CANCELAR el mensaje y que sea invisible
world.beforeEvents.chatSend.subscribe((event) => {
    const player = event.sender;
    const message = event.message.trim();

    if (message.startsWith("!")) {
        event.cancel = true; // OCULTA EL COMANDO DEL CHAT PÚBLICO
        
        system.run(() => {
            const args = message.substring(1).split(" ");
            const command = args[0].toLowerCase();
            const textArgs = args.slice(1).join(" ");

            switch (command) {
                case "clan":
                    showMainClanMenu(player);
                    break;
                case "c":
                    if (!textArgs) return player.sendMessage("§cUso: !c <mensaje>");
                    ClanChat.sendMessage(player, textArgs);
                    break;
                case "msg":
                    // Aquí iría tu lógica de MSG que ya tenías...
                    player.sendMessage("§e[Nexus] Usa el menú Social para mensajes.");
                    break;
                default:
                    player.sendMessage("§c[Nexus] Comando no reconocido.");
            }
        });
    } else {
        if (AntiSpam.isSpamming(player.name)) {
            event.cancel = true; // Cancela el spam
            system.run(() => player.sendMessage("§c[Nexus] ¡No hagas Spam!"));
        }
    }
});

// Limpieza al salir
world.afterEvents.playerLeave.subscribe((event) => {
    const playerName = event.playerName;
    if (playerName) {
        AntiSpam.clearPlayer(playerName);
        PrivateChat.clearCache(playerName);
        ClanInvites.clearInvite(playerName);
    }
});