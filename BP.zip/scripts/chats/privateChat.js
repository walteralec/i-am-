import { world, system } from "@minecraft/server";

const replyCache = new Map();

export const PrivateChat = {
    sendMessage(sender, targetName, message) {
        system.run(() => {
            const targetPlayer = world.getAllPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
            if (!targetPlayer) return sender.sendMessage(`§c[Nexus] §7Jugador no encontrado.`);
            if (sender.name === targetPlayer.name) return sender.sendMessage("§c[Nexus] §7No puedes enviarte mensajes a ti mismo.");

            sender.sendMessage(`§8[§dYo §8-> §d${targetPlayer.name}§8] §f${message}`);
            targetPlayer.sendMessage(`§8[§d${sender.name} §8-> §dMí§8] §f${message}`);

            replyCache.set(sender.name, targetPlayer.name);
            replyCache.set(targetPlayer.name, sender.name);
        });
    },
    replyMessage(sender, message) {
        const targetName = replyCache.get(sender.name);
        if (!targetName) return system.run(() => sender.sendMessage("§c[Nexus] §7Nadie a quien responder."));
        this.sendMessage(sender, targetName, message);
    },
    clearCache(playerName) {
        replyCache.delete(playerName);
    }
};