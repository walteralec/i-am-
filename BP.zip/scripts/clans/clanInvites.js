import { system } from "@minecraft/server";

const pendingInvites = new Map();

export const ClanInvites = {
    sendInvite(targetName, clanTag) {
        pendingInvites.set(targetName, clanTag);
        system.runTimeout(() => {
            if (pendingInvites.get(targetName) === clanTag) {
                pendingInvites.delete(targetName);
            }
        }, 1200); // 60 segundos
    },
    getInvite(targetName) {
        return pendingInvites.get(targetName) || null;
    },
    clearInvite(targetName) {
        pendingInvites.delete(targetName);
    }
};