import { Database } from "../core/database.js";
import { claimCache } from "../territories/territoryManager.js";

export const playerClanCache = new Map();

export const ClanManager = {
    initCache() {
        const clanTags = Database.load("nexus_clans_list", []);
        for (const tag of clanTags) {
            const clanData = Database.load(`nexus_clan_${tag}`);
            if (clanData && clanData.members) {
                Object.keys(clanData.members).forEach(playerName => {
                    playerClanCache.set(playerName, tag);
                });
            }
        }
    },
    createClan(tag, name, leaderName) {
        const upperTag = tag.toUpperCase();
        const clanTags = Database.load("nexus_clans_list", []);

        if (clanTags.includes(upperTag) || playerClanCache.has(leaderName)) return false;

        const newClan = {
            tag: upperTag,
            name: name,
            leader: leaderName,
            creationDate: Date.now(),
            members: {},
            claims: [] // Inicialización limpia de la base de reclamos interna
        };

        newClan.members[leaderName] = { role: "leader", joinedAt: Date.now() };

        clanTags.push(upperTag);
        Database.save("nexus_clans_list", clanTags);
        Database.save(`nexus_clan_${upperTag}`, newClan);
        playerClanCache.set(leaderName, upperTag);
        
        return true;
    },
    getClan(tag) {
        return Database.load(`nexus_clan_${tag.toUpperCase()}`);
    },
    getPlayerClanTag(playerName) {
        return playerClanCache.get(playerName) || null;
    },
    deleteClan(tag) {
        const upperTag = tag.toUpperCase();
        let clanTags = Database.load("nexus_clans_list", []);
        
        if (!clanTags.includes(upperTag)) return false;

        const clanData = this.getClan(upperTag);
        if (clanData) {
            Object.keys(clanData.members).forEach(member => playerClanCache.delete(member));
            // CORRECCIÓN: Al eliminar el clan, se liberan sus reclamos de la memoria RAM instantáneamente
            if (clanData.claims) {
                clanData.claims.forEach(chunkId => claimCache.delete(chunkId));
            }
        }

        clanTags = clanTags.filter(t => t !== upperTag);
        Database.save("nexus_clans_list", clanTags);
        Database.delete(`nexus_clan_${upperTag}`);
        
        return true;
    },
    addMember(playerName, tag) {
        const upperTag = tag.toUpperCase();
        
        // CORRECCIÓN: Evita el exploit quitando al jugador de su clan anterior si ya tenía uno
        if (playerClanCache.has(playerName)) {
            this.removeMember(playerName);
        }

        const clan = this.getClan(upperTag);
        if (!clan || Object.keys(clan.members).length >= 15) return false;

        clan.members[playerName] = { role: "member", joinedAt: Date.now() };
        Database.save(`nexus_clan_${upperTag}`, clan);
        playerClanCache.set(playerName, upperTag);
        
        return true;
    },
    removeMember(playerName) {
        const tag = this.getPlayerClanTag(playerName);
        if (!tag) return false;

        const clan = this.getClan(tag);
        if (!clan) return false;

        if (clan.members[playerName].role === "leader" && Object.keys(clan.members).length > 1) {
            return "is_leader";
        }

        delete clan.members[playerName];

        if (Object.keys(clan.members).length === 0) {
            this.deleteClan(tag);
        } else {
            Database.save(`nexus_clan_${tag}`, clan);
        }

        playerClanCache.delete(playerName);
        return true;
    }
};