import { Database } from "../core/database.js";
import { ClanManager } from "./clanManager.js";

const ROLE_WEIGHTS = { "leader": 4, "coleader": 3, "moderator": 2, "member": 1 };

export const ClanRoles = {
    hasPermission(playerName, requiredRole) {
        const tag = ClanManager.getPlayerClanTag(playerName);
        if (!tag) return false;

        const clan = ClanManager.getClan(tag);
        if (!clan || !clan.members[playerName]) return false;

        return ROLE_WEIGHTS[clan.members[playerName].role] >= ROLE_WEIGHTS[requiredRole];
    },
    setRole(executorName, targetName, newRole) {
        const tag = ClanManager.getPlayerClanTag(executorName);
        if (!tag || tag !== ClanManager.getPlayerClanTag(targetName)) return false;
        if (!ROLE_WEIGHTS[newRole] || !this.hasPermission(executorName, "coleader")) return false;

        const clan = ClanManager.getClan(tag);
        clan.members[targetName].role = newRole;
        Database.save(`nexus_clan_${tag}`, clan);
        
        return true;
    }
};