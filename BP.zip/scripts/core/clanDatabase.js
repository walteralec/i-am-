import { Database } from "./database.js";

export const ClanBaseManager = {
    /**
     * Define la base de un clan.
     * Guarda: { x, y, z, radius }
     */
    setClanBase(clanName, location, radius = 20) {
        const clanData = Database.get(`clan_${clanName}`);
        if (!clanData) return false;

        clanData.base = {
            x: Math.floor(location.x),
            y: Math.floor(location.y),
            z: Math.floor(location.z),
            radius: radius
        };

        Database.set(`clan_${clanName}`, clanData);
        return true;
    },

    /**
     * Verifica si una posición está dentro de una base protegida
     * Retorna el nombre del clan si está dentro, null si es terreno libre
     */
    getClaimAtPosition(location) {
        const allClans = Database.getAllClans(); // Asumiendo que tienes este método

        for (const clanName of allClans) {
            const data = Database.get(`clan_${clanName}`);
            if (!data.base) continue;

            const dist = Math.sqrt(
                Math.pow(location.x - data.base.x, 2) +
                Math.pow(location.z - data.base.z, 2) // Usamos XZ para evitar problemas de altura (cielo/subsuelo)
            );

            if (dist <= data.base.radius) return clanName;
        }
        return null;
    }
};