import { world } from "@minecraft/server";

export class Database {
    // --- SISTEMA GLOBAL ---
    static load(key, defaultValue = null) {
        const val = world.getDynamicProperty(key);
        if (val === undefined) return defaultValue;
        try { return JSON.parse(val); } catch(e) { return val; }
    }

    static save(key, value) {
        const str = typeof value === 'object' ? JSON.stringify(value) : value.toString();
        world.setDynamicProperty(key, str);
    }

    static delete(key) {
        world.setDynamicProperty(key, undefined);
    }

    // --- SISTEMA DE CLANES ---
    static getClanList() {
        return this.load(`nexus_clan_list`, []);
    }

    static saveClanList(list) {
        this.save(`nexus_clan_list`, list);
    }

    static getClanData(clanName) {
        return this.load(`nexus_clan_${clanName.toLowerCase()}`, null);
    }

    static saveClanData(clanName, data) {
        this.save(`nexus_clan_${clanName.toLowerCase()}`, data);
    }

    static createClan(name, leaderName) {
        const list = this.getClanList();
        if (list.some(c => c.name.toLowerCase() === name.toLowerCase())) return false;
        
        const newClan = {
            name: name,
            leader: leaderName,
            members: [leaderName],
            createdAt: new Date().toLocaleDateString()
        };
        
        list.push({ name: name, leader: leaderName });
        this.saveClanList(list);
        this.saveClanData(name, newClan);
        return true;
    }

    // --- GESTIÓN DE MIEMBROS ---
    static addMemberToClan(clanName, playerName) {
        const clan = this.getClanData(clanName);
        if (clan && !clan.members.includes(playerName)) {
            clan.members.push(playerName);
            this.saveClanData(clanName, clan);
            return true;
        }
        return false;
    }

    static kickMember(clanName, memberName) {
        const clan = this.getClanData(clanName);
        if (!clan) return false;
        
        // Seguridad: No expulsar al líder
        if (clan.leader === memberName) return false;
        
        // Filtramos al miembro
        const initialLength = clan.members.length;
        clan.members = clan.members.filter(m => m !== memberName);
        
        // Si el tamaño cambió, guardamos
        if (clan.members.length !== initialLength) {
            this.saveClanData(clanName, clan);
            return true;
        }
        return false;
    }

    // --- SISTEMA DE JUGADOR ---
    static getPlayerData(player) {
        const tags = player.getTags();
        const dataTag = tags.find(tag => tag.startsWith("nexus_data:"));
        if (!dataTag) return { bookmarks: [] };
        try { return JSON.parse(dataTag.substring(11)); } catch (e) { return { bookmarks: [] }; }
    }

    static savePlayerData(player, dataObj) {
        const tags = player.getTags();
        const oldTag = tags.find(tag => tag.startsWith("nexus_data:"));
        if (oldTag) player.removeTag(oldTag);
        const newTag = `nexus_data:${JSON.stringify(dataObj)}`;
        player.addTag(newTag);
    }

    // --- BUZÓN DE ENTRADA ---
    static getInbox(playerName) {
        return this.load(`nexus_inbox_${playerName.toLowerCase()}`, []);
    }

    static addMessageToInbox(targetPlayerName, senderName, messageText) {
        const inbox = this.getInbox(targetPlayerName);
        inbox.unshift({ sender: senderName, text: messageText, date: new Date().toLocaleDateString(), read: false });
        if (inbox.length > 20) inbox.pop(); 
        this.save(`nexus_inbox_${targetPlayerName.toLowerCase()}`, inbox);
    }

    static markMessageAsRead(playerName, index) {
        const inbox = this.getInbox(playerName);
        if (inbox[index]) {
            inbox[index].read = true;
            this.save(`nexus_inbox_${playerName.toLowerCase()}`, inbox);
        }
    }

    static deleteMessage(playerName, index) {
        const inbox = this.getInbox(playerName);
        if (inbox[index] !== undefined) {
            inbox.splice(index, 1); 
            this.save(`nexus_inbox_${playerName.toLowerCase()}`, inbox);
        }
    }

    static cleanupInbox(playerName) {
        let inbox = this.getInbox(playerName);
        if (inbox.length > 20) inbox = inbox.slice(0, 20);
        const unread = inbox.filter(m => !m.read);
        const read = inbox.filter(m => m.read).slice(0, 5); 
        const newInbox = [...unread, ...read];
        this.save(`nexus_inbox_${playerName.toLowerCase()}`, newInbox);
    }

    // --- SISTEMA DE BLOQUEO ---
    static getBlockedList(playerName) {
        return this.load(`nexus_blocked_${playerName.toLowerCase()}`, []);
    }

    static isBlocked(ownerName, targetName) {
        return this.getBlockedList(ownerName).includes(targetName.toLowerCase());
    }

    static blockPlayer(ownerName, targetName) {
        const blocked = this.getBlockedList(ownerName);
        const target = targetName.toLowerCase();
        if (!blocked.includes(target)) {
            blocked.push(target);
            this.save(`nexus_blocked_${ownerName.toLowerCase()}`, blocked);
        }
    }

    static unblockPlayer(ownerName, targetName) {
        let blocked = this.getBlockedList(ownerName);
        blocked = blocked.filter(n => n !== targetName.toLowerCase());
        this.save(`nexus_blocked_${ownerName.toLowerCase()}`, blocked);
    }

    // --- SISTEMA DE INVITACIONES ---
    static invitePlayerToClan(senderName, targetName, clanName) {
        const inviteText = `§l⚔️ INVITACIÓN AL CLAN\n§rEl jugador §e${senderName} §fte invita a unirte al clan §e${clanName}§f.\n\n§7Responde 'ACEPTAR' para unirte.`;
        this.addMessageToInbox(targetName, senderName, inviteText);
    }
}