/**
 * Gestor de Grupos Temporales (RAM)
 * Estructura: Map<groupId, { leader, members: string[] }>
 */
const activeGroups = new Map();
const playerGroups = new Map(); // Mapa de búsqueda rápida: playerName -> groupId

export const GroupManager = {
    /**
     * Crea un nuevo grupo y asigna al líder
     */isPlayerInGroup(player) {
        return playerGroups.has(player.name);
    },

    getGroupId(player) {
        return playerGroups.get(player.name);
    }
    createGroup(player) {
        if (playerGroups.has(player.name)) return null;

        const groupId = `grp_${player.name}`;
        const groupData = {
            id: groupId,
            leader: player.name,
            members: [player.name]
        };

        activeGroups.set(groupId, groupData);
        playerGroups.set(player.name, groupId);
        
        // Asignamos tag visual para distinguir miembros del grupo
        player.addTag("in_group");
        return groupId;
    },

    /**
     * Añade un jugador a un grupo existente
     */
    joinGroup(groupId, player) {
        const group = activeGroups.get(groupId);
        if (!group || playerGroups.has(player.name)) return false;

        group.members.push(player.name);
        playerGroups.set(player.name, groupId);
        player.addTag("in_group");
        return true;
    },

    /**
     * Elimina a un jugador del grupo
     */
    leaveGroup(player) {
        const groupId = playerGroups.get(player.name);
        if (!groupId) return;

        const group = activeGroups.get(groupId);
        group.members = group.members.filter(m => m !== player.name);
        
        player.removeTag("in_group");
        playerGroups.delete(player.name);

        // Si el grupo queda vacío, se elimina
        if (group.members.length === 0) {
            activeGroups.delete(groupId);
        } else if (group.leader === player.name) {
            // Transferencia de liderazgo simple
            group.leader = group.members[0];
        }
    },

    getGroupMembers(player) {
        const groupId = playerGroups.get(player.name);
        return groupId ? activeGroups.get(groupId).members : [];
    }
};
// ... (mantiene tu código anterior de activeGroups y playerGroups)


    // ... (mantiene tus métodos createGroup, joinGroup, leaveGroup, getGroupMembers)

    // NUEVO: Métodos para consultar estado desde el menú
    
    
    // ...
};