import { world } from "@minecraft/server";
import { Database } from "../core/database.js";

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;
    
    // Solo notificamos si es el inicio de sesión real (evita spam al morir/teletransporte)
    if (event.initialSpawn) {
        
        // 1. Check de Mensajes
        const inbox = Database.getInbox(player.name);
        const unreadMessages = inbox.filter(m => !m.read);
        
        // 2. Check de Clan (buscando el tag)
        // Buscamos un tag que empiece por 'clan:'
        const clanTag = player.getTags().find(t => t.startsWith("clan:"));
        const clanName = clanTag ? clanTag.split(":")[1] : "Ninguno";

        // 3. Notificación "Dashboard" de Bienvenida
        player.onScreenDisplay.setTitle("§l§eBIENVENIDO A NEXUS", {
            subtitle: `Clan: §a${clanName} §f| Mensajes: §e${unreadMessages.length}`,
            fadeInDuration: 20,
            stayDuration: 100,
            fadeOutDuration: 20
        });

        // 4. Feedback detallado en chat
        player.sendMessage(`§l§e[Nexus] §r§f¡Hola, §b${player.name}§f!`);
        
        if (unreadMessages.length > 0) {
            player.sendMessage(`§7Tienes §e${unreadMessages.length} §7mensajes sin leer en tu buzón.`);
            player.runCommandAsync("playsound random.levelup @s ~ ~ ~ 1 1");
        }
        
        if (clanName !== "Ninguno") {
            player.sendMessage(`§7Estás representando al clan: §a${clanName}`);
        } else {
            player.sendMessage(`§7No tienes clan. ¡Usa el menú social para crear uno!`);
        }
    }
});