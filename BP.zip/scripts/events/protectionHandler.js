import { world } from "@minecraft/server";
import { ClanBaseManager } from "../core/clanDatabase.js";
import { Database } from "../core/database.js"; // Import necesario para el registro

// Lista de bloques protegidos
const PROTECTED_BLOCKS = [
    "minecraft:chest", "minecraft:trapped_chest", "minecraft:barrel",
    "minecraft:furnace", "minecraft:blast_furnace", "minecraft:smoker",
    "minecraft:crafting_table", "minecraft:ender_chest", "minecraft:shulker_box",
    "minecraft:wooden_door", "minecraft:iron_door", "minecraft:fence_gate"
];

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { block, player } = event;
    const blockType = block.typeId;

    // 1. Solo filtrar bloques de la lista protegida
    if (!PROTECTED_BLOCKS.includes(blockType)) return;

    // 2. Consultar si el bloque está en territorio de algún clan
    const ownerClanName = ClanBaseManager.getClaimAtPosition(block.location);

    // 3. Si no hay clan dueño, terreno libre
    if (!ownerClanName) return;

    // 4. Verificar si el jugador es miembro del clan
    if (!player.hasTag(`clan:${ownerClanName}`)) {
        event.cancel = true;
        
        // --- Feedback al Intruso ---
        player.sendMessage(`§c[Nexus] Prohibido: Este bloque pertenece al clan §e${ownerClanName}§c.`);
        player.dimension.spawnParticle("minecraft:knockback_roar_particle", block.center());
        player.runCommandAsync("playsound random.click @s ~ ~ ~ 1 0.5");

        // --- Sistema de Alerta (Log de Evidencias) ---
        const clanData = Database.getClanData(ownerClanName);
        if (clanData && clanData.leader) {
            // Registro en el buzón del líder (Persistencia)
            const logMsg = `§l§c⚠️ ALERTA DE INTRUSIÓN\n§fEl jugador §e${player.name} §fintentó interactuar con §7${blockType} §fen tu base.`;
            Database.addMessageToInbox(clanData.leader, "SISTEMA (Seguridad)", logMsg);

            // Notificación en vivo si el líder está online
            const leaderPlayer = world.getPlayers().find(p => p.name === clanData.leader);
            if (leaderPlayer) {
                leaderPlayer.sendMessage(`§c[Nexus] ¡Alerta! ${player.name} intentó forzar un bloque en tu base.`);
                leaderPlayer.runCommandAsync("playsound mob.wither.break_block @s ~ ~ ~ 1 1");
            }
        }
    }
});