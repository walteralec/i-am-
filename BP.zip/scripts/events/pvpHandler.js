import { world, system } from "@minecraft/server";
import { TeamManager } from "./teamManager.js"; // Mantén tu gestor de parties si lo usas

export const TeamDamageSystem = {
    areAllies(entityA, entityB) {
        if (!entityA || !entityB || entityA.typeId !== "minecraft:player" || entityB.typeId !== "minecraft:player") return false;
        
        // 1. Verificación por Clan (usando el sistema de tags que implementamos)
        const clanA = entityA.getTags().find(t => t.startsWith("clan:"));
        const clanB = entityB.getTags().find(t => t.startsWith("clan:"));
        
        if (clanA && clanB && clanA === clanB) return true;

        // 2. Verificación por Party/Team (mantenemos tu TeamManager)
        const partyA = TeamManager.getParty(entityA.name);
        const partyB = TeamManager.getParty(entityB.name);
        if (partyA && partyB && partyA === partyB) return true;

        return false;
    },

    resolveDamager(damagingEntity) {
        if (!damagingEntity) return null;
        
        // Si el dañador es un jugador, retornamos la entidad
        if (damagingEntity.typeId === "minecraft:player") return damagingEntity;
        
        // Si es una mascota (lobo/gato), resolvemos al dueño
        const tameable = damagingEntity.getComponent("minecraft:tameable");
        if (tameable && tameable.tamedToPlayerId) {
            return world.getAllPlayers().find(p => p.id === tameable.tamedToPlayerId) || null;
        }
        return null;
    }
};

world.afterEvents.entityHurt.subscribe((event) => {
    const victim = event.hurtEntity;
    
    // Solo nos importa si la víctima es un jugador
    if (victim.typeId !== "minecraft:player") return;

    // Resolvemos quién causó el daño (jugador o mascota de jugador)
    const damagerPlayer = TeamDamageSystem.resolveDamager(event.damageSource.damagingEntity);
    
    // Si no hay atacante o se está golpeando a sí mismo (ej. caída, espinas), ignoramos
    if (!damagerPlayer || victim.id === damagerPlayer.id) return;

    // Verificamos alianza
    if (TeamDamageSystem.areAllies(victim, damagerPlayer)) {
        system.run(() => {
            const healthComp = victim.getComponent("minecraft:health");
            if (healthComp) {
                // Restauramos la salud restada inmediatamente
                const newHealth = Math.min(healthComp.currentValue + event.damage, healthComp.effectiveMax);
                healthComp.setCurrentValue(newHealth);
                
                // Feedback discreto
                damagerPlayer.onScreenDisplay.setActionBar("§c¡Estás golpeando a un aliado!");
            }
        });
    }
});