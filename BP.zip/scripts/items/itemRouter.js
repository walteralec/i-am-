import { world, system } from "@minecraft/server";
import { showMainHub } from "../ui/mainHub.js";

world.beforeEvents.itemUse.subscribe((event) => {
    if (event.itemStack.typeId === "minecraft:blaze_rod") {
        const player = event.source;
        
        // Notificación en ActionBar
        player.runCommandAsync(`title @s actionbar §eAbriendo Nexus Hub...`);
        
        // Retraso de 1 tick para evitar errores de UI en Bedrock
        system.runTimeout(() => {
            showMainHub(player);
        }, 1);
    }
});