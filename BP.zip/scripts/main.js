import { world } from "@minecraft/server";
import { GroupManager } from "./core/groupManager.js"; 
import "./events/protectionHandler.js";
import "./events/loginNotify.js"; 
import "./events/pvpHandler.js";
import "./items/itemRouter.js";
import "./chats/chatRouter.js";
import { setupChatHandler } from "./chats/chatHandler.js";

// --- SISTEMA DE CHAT DE GRUPO (PARTY) ---
world.beforeEvents.chatSend.subscribe((event) => {
    const { sender, message } = event;
    
    // Si el mensaje empieza con "!", es chat de grupo
    if (message.startsWith("!")) {
        const members = GroupManager.getGroupMembers(sender);
        
        if (members.length === 0) {
            sender.sendMessage("§c[Nexus] No estás en ningún grupo.");
            event.cancel = true;
            return;
        }

        event.cancel = true;
        const chatContent = message.substring(1).trim();
        if (chatContent.length === 0) return;

        const formattedMsg = `§7[§eGrupo§7] §f${sender.name}§7: §f${chatContent}`;

        members.forEach(memberName => {
            const member = world.getPlayers().find(p => p.name === memberName);
            if (member) member.sendMessage(formattedMsg);
        });
    }
});

// --- GESTIÓN DE SALIDA (LIMPIEZA) ---
world.afterEvents.playerLeave.subscribe((event) => {
    GroupManager.leaveGroup(event.player);
});

// --- INICIALIZACIÓN ---
world.beforeEvents.worldInitialize.subscribe((initEvent) => {
    console.warn("[Nexus] Preparando el entorno del servidor...");
});

world.afterEvents.worldInitialize.subscribe(() => {
    setupChatHandler(); // Activamos Clan Tags
    
    console.warn("[Nexus] Ecosistema UI y Sistema PRO Cargados.");
    console.warn("[Nexus] Clan Tags activados.");
    console.warn("[Nexus] Party Chat funcional (!mensaje).");
    console.warn("[Nexus] Comandos por chat desactivados. Usa el Nexus Tool.");
});