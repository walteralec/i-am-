import { world, system } from "@minecraft/server";
import { ClanManager } from "../clans/clanManager.js";
import { TeamManager } from "./teamManager.js";

export const TeamDamageSystem = {
    areAllies(entityA, entityB) {
        if (!entityA || !entityB || entityA.typeId !== "minecraft:player" || entityB.typeId !== "minecraft:player") return false;
        
        const clanA = ClanManager.getPlayerClanTag(entityA.name);
        const clanB = ClanManager.getPlayerClanTag(entityB.name);
        if (clanA && clanB && clanA === clanB) return true;

        const partyA = TeamManager.getParty(entityA.name);
        const partyB = TeamManager.getParty(entityB.name);
        if (partyA && partyB && partyA === partyB) return true;

        return false;
    },
    resolveDamager(damagingEntity) {
        if (!damagingEntity) return null;
        if (damagingEntity.typeId === "minecraft:player") return damagingEntity;
        
        const tameable = damagingEntity.getComponent("minecraft:tameable");
        if (tameable && tameable.tamedToPlayerId) {
            return world.getAllPlayers().find(p => p.id === tameable.tamedToPlayerId) || null;
        }
        return null;
    }
};

world.afterEvents.entityHurt.subscribe((event) => {
    const victim = event.hurtEntity;
    if (victim.typeId !== "minecraft:player") return;

    const damagerPlayer = TeamDamageSystem.resolveDamager(event.damageSource.damagingEntity);
    if (!damagerPlayer || victim.name === damagerPlayer.name) return;

    if (TeamDamageSystem.areAllies(victim, damagerPlayer)) {
        system.run(() => {
            const healthComp = victim.getComponent("minecraft:health");
            if (healthComp) {
                // CORRECCIÓN: effectiveMax respeta los corazones extra de pociones/manzanas doradas
                healthComp.setCurrentValue(Math.min(healthComp.currentValue + event.damage, healthComp.effectiveMax));
                damagerPlayer.onScreenDisplay.setActionBar("§c¡Estás golpeando a un aliado!");
            }
        });
    }
});