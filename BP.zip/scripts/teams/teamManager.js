import { system } from "@minecraft/server";

export const partyCache = new Map();
const partyInvites = new Map();

export const TeamManager = {
    getParty(playerName) {
        return partyCache.get(playerName) || null;
    },
    invite(leaderName, targetName) {
        if (this.getParty(leaderName) && this.getParty(leaderName) !== leaderName) return "not_leader";
        if (this.getParty(targetName)) return "already_in_party";
        
        partyInvites.set(targetName, leaderName);
        system.runTimeout(() => {
            if (partyInvites.get(targetName) === leaderName) {
                partyInvites.delete(targetName);
            }
        }, 1200); // 60 segundos
        
        return "success";
    },
    accept(playerName) {
        const leader = partyInvites.get(playerName);
        if (!leader) return false;
        
        partyCache.set(leader, leader);
        partyCache.set(playerName, leader);
        partyInvites.delete(playerName);
        return leader;
    },
    leave(playerName) {
        const partyId = partyCache.get(playerName);
        if (!partyId) return false;

        if (partyId === playerName) {
            for (const [member, id] of partyCache.entries()) {
                if (id === partyId) partyCache.delete(member);
            }
            return "disbanded";
        } else {
            partyCache.delete(playerName);
            return "left";
        }
    }
};