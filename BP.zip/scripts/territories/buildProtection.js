import { world, system } from "@minecraft/server";
import { TerritoryManager } from "./territoryManager.js";
import { ClanManager } from "../clans/clanManager.js";
import { Logger } from "../core/logger.js";

const PROTECTED_BLOCKS = [
    "minecraft:chest", "minecraft:barrel", "minecraft:shulker_box", "minecraft:ender_chest",
    "minecraft:furnace", "minecraft:blast_furnace", "minecraft:smoker", "minecraft:hopper",
    "minecraft:dispenser", "minecraft:dropper",
    "minecraft:wooden_door", "minecraft:iron_door", "minecraft:trapdoor", 
    "minecraft:lever", "minecraft:stone_button", "minecraft:wooden_button"
];

function isProtected(player, blockLocation, dimensionId) {
    const chunkId = TerritoryManager.getChunkId(blockLocation, dimensionId);
    const ownerClan = TerritoryManager.getChunkOwner(chunkId);
    if (!ownerClan || ClanManager.getPlayerClanTag(player.name) === ownerClan) return false;
    return true;
}

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    // CORRECCIÓN: Se usa event.player.dimension.id
    if (isProtected(event.player, event.block.location, event.player.dimension.id)) {
        event.cancel = true;
        system.run(() => event.player.onScreenDisplay.setActionBar("§cTerritorio enemigo."));
    }
});

world.beforeEvents.playerPlaceBlock.subscribe((event) => {
    // CORRECCIÓN: Se usa event.player.dimension.id
    if (isProtected(event.player, event.block.location, event.player.dimension.id)) {
        event.cancel = true;
        system.run(() => event.player.onScreenDisplay.setActionBar("§cTerritorio enemigo."));
    }
});

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    if (PROTECTED_BLOCKS.some(block => event.block.typeId.includes(block.replace("minecraft:", "")))) {
        // CORRECCIÓN: Se usa event.player.dimension.id
        if (isProtected(event.player, event.block.location, event.player.dimension.id)) {
            event.cancel = true;
            
            const chunkId = TerritoryManager.getChunkId(event.block.location, event.player.dimension.id);
            const ownerClan = TerritoryManager.getChunkOwner(chunkId);
            
            system.run(() => {
                event.player.onScreenDisplay.setActionBar("§cEste bloque pertenece a otro clan.");
                Logger.logEvent("robo", `${event.player.name} intentó usar un bloque en territorio de [${ownerClan}] en X:${Math.floor(event.block.location.x)} Z:${Math.floor(event.block.location.z)}`);
            });
        }
    }
});