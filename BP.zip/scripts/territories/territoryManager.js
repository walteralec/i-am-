import { Database } from "../core/database.js";

export const claimCache = new Map();

export const TerritoryManager = {
    getChunkId(location, dimensionId) {
        return `${dimensionId}_${Math.floor(location.x / 16)}_${Math.floor(location.z / 16)}`;
    },
    initCache() {
        // CORRECCIÓN: Ahora lee los chunks desde cada clan de forma segura para evitar desbordamiento de memoria
        const clanTags = Database.load("nexus_clans_list", []);
        for (const tag of clanTags) {
            const clanData = Database.load(`nexus_clan_${tag}`);
            if (clanData && clanData.claims) {
                for (const chunkId of clanData.claims) {
                    claimCache.set(chunkId, tag);
                }
            }
        }
    },
    getChunkOwner(chunkId) {
        return claimCache.get(chunkId) || null;
    },
    claimChunk(chunkId, clanTag) {
        if (this.getChunkOwner(chunkId)) return "already_claimed";
        
        const clan = Database.load(`nexus_clan_${clanTag}`);
        if (!clan) return "error";
        
        if (!clan.claims) clan.claims = [];
        if (clan.claims.length >= 10) return "limit_reached";

        // CORRECCIÓN: Los datos se guardan directo en la estructura del clan
        clan.claims.push(chunkId);
        Database.save(`nexus_clan_${clanTag}`, clan);
        claimCache.set(chunkId, clanTag);
        
        return "success";
    },
    unclaimChunk(chunkId, clanTag) {
        if (this.getChunkOwner(chunkId) !== clanTag) return false;

        const clan = Database.load(`nexus_clan_${clanTag}`);
        if (!clan || !clan.claims) return false;

        clan.claims = clan.claims.filter(id => id !== chunkId);
        Database.save(`nexus_clan_${clanTag}`, clan);
        claimCache.delete(chunkId);
        
        return true;
    }
};