import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { ClanManager } from "../clans/clanManager.js";
import { ClanInvites } from "../clans/clanInvites.js";
import { TerritoryManager } from "../territories/territoryManager.js";
import { ClanRoles } from "../clans/clanRoles.js";
import { world, system } from "@minecraft/server";

export function showMainClanMenu(player) {
    const clanTag = ClanManager.getPlayerClanTag(player.name);
    if (!clanTag) showNoClanMenu(player);
    else showActiveClanMenu(player, clanTag);
}

function showNoClanMenu(player) {
    new ActionFormData()
        .title("§l§9Nexus §8| §fClanes")
        .body("No perteneces a ningún clan.")
        .button("§l§2Crear un Clan")
        .button("§l§cCerrar")
        .show(player).then(r => {
            if (!r.canceled && r.selection === 0) showCreateClanForm(player);
        }).catch(() => {});
}

function showCreateClanForm(player) {
    new ModalFormData()
        .title("§l§9Crear Nuevo Clan")
        .textField("Etiqueta (Tag) [Máx 4]:", "Ej: WAR")
        .textField("Nombre completo:", "Ej: Warriors")
        .show(player).then(r => {
            if (r.canceled) return;
            const [tag, name] = r.formValues;
            if (!tag || tag.length < 2 || tag.length > 4) return player.sendMessage("§c[Nexus] §7Tag inválido.");
            
            system.run(() => {
                if (ClanManager.createClan(tag, name, player.name)) {
                    player.sendMessage(`§a[Nexus] §7Clan §b[${tag.toUpperCase()}] §7creado.`);
                } else {
                    player.sendMessage("§c[Nexus] §7Ese Tag ya está en uso.");
                }
            });
        });
}

function showActiveClanMenu(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return;

    const role = clan.members[player.name].role;
    const isLeader = role === "leader" || role === "coleader";

    const form = new ActionFormData()
        .title(`§l§9Clan §8[§b${tag}§8]`)
        .body(`§7Nombre: §f${clan.name}\n§7Rango: §a${role}\n§7Miembros: §e${Object.keys(clan.members).length}/15`)
        .button("§l§3Ver Miembros");

    if (isLeader) {
        form.button("§l§2Invitar Jugador");
        form.button("§l§6Gestión de Territorio");
    }
    form.button("§l§cAbandonar Clan");

    form.show(player).then((response) => {
        if (response.canceled) return;
        if (response.selection === 0) showMemberList(player, tag);
        else if (response.selection === 1 && isLeader) showInviteForm(player, tag);
        else if (response.selection === 2 && isLeader) showTerritoryMenu(player, tag);
        else showLeaveConfirm(player);
    });
}

function showMemberList(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return;

    const myRole = clan.members[player.name].role;
    const isLeaderOrCo = myRole === "leader" || myRole === "coleader";
    const membersList = Object.keys(clan.members);
    
    const form = new ActionFormData()
        .title("§l§3Miembros del Clan")
        .body(`Selecciona un jugador para ver detalles${isLeaderOrCo ? " o gestionarlo" : ""}.`);

    for (const member of membersList) {
        form.button(`${member}\n§8Rango: §7${clan.members[member].role}`);
    }

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedMember = membersList[response.selection];
        
        if (isLeaderOrCo && selectedMember !== player.name) {
            showMemberManagement(player, selectedMember, tag, clan.members[selectedMember].role);
        } else {
            player.sendMessage(`§e[Nexus] §7Viendo perfil de §f${selectedMember}§7.`);
        }
    });
}

function showMemberManagement(player, targetName, tag, currentRole) {
    new ActionFormData()
        .title("§l§cGestión de Miembro")
        .body(`§7Jugador: §f${targetName}\n§7Rango Actual: §a${currentRole}`)
        .button("§l§2Ascender (Sublíder)")
        .button("§l§eDegradar (Miembro)")
        .button("§l§4Expulsar del Clan")
        .show(player).then((r) => {
            if (r.canceled) return;
            system.run(() => {
                if (r.selection === 0 && ClanRoles.setRole(player.name, targetName, "coleader")) {
                    player.sendMessage(`§a[Nexus] §7${targetName} ha sido ascendido.`);
                } else if (r.selection === 1 && ClanRoles.setRole(player.name, targetName, "member")) {
                    player.sendMessage(`§e[Nexus] §7${targetName} ha sido degradado.`);
                } else if (r.selection === 2) {
                    ClanManager.removeMember(targetName);
                    player.sendMessage(`§c[Nexus] §7${targetName} ha sido expulsado.`);
                    world.sendMessage(`§8[§b${tag}§8] §7${targetName} §7fue expulsado.`);
                }
            });
        });
}

function showTerritoryMenu(player, tag) {
    const chunkId = TerritoryManager.getChunkId(player.location, player.dimension.id);
    const owner = TerritoryManager.getChunkOwner(chunkId);
    
    let statusText = owner === tag ? "§2Protegido por tu Clan" : (owner ? `§cOcupado por [${owner}]` : "§aLibre");

    const form = new ActionFormData()
        .title("§l§6Territorio")
        .body(`§7Chunk:\n§f${chunkId}\n\n§7Estado: ${statusText}`);

    if (!owner) form.button("§l§2Reclamar Zona");
    else if (owner === tag) form.button("§l§cLiberar Zona");
    else form.button("§l§8Zona Enemiga");

    form.show(player).then((r) => {
        if (r.canceled) return;
        system.run(() => {
            if (!owner && r.selection === 0) {
                const res = TerritoryManager.claimChunk(chunkId, tag);
                if (res === "success") player.sendMessage("§a[Nexus] §7Territorio asegurado.");
                else if (res === "limit_reached") player.sendMessage("§c[Nexus] §7Límite de territorios alcanzado.");
            } else if (owner === tag && r.selection === 0) {
                TerritoryManager.unclaimChunk(chunkId, tag);
                player.sendMessage("§e[Nexus] §7Territorio liberado.");
            }
        });
    });
}

function showInviteForm(player, tag) {
    const players = world.getAllPlayers().filter(p => !ClanManager.getPlayerClanTag(p.name));
    if (players.length === 0) return player.sendMessage("§c[Nexus] §7No hay jugadores disponibles.");

    const names = players.map(p => p.name);
    new ModalFormData().title("§l§9Invitar Jugador").dropdown("Selecciona:", names).show(player).then(r => {
        if (r.canceled) return;
        const target = players.find(p => p.name === names[r.formValues[0]]);
        if (target) {
            ClanInvites.sendInvite(target.name, tag);
            player.sendMessage(`§a[Nexus] §7Invitación enviada a ${target.name}.`);
            target.sendMessage(`§a[Nexus] §7Has sido invitado a §b[${tag}]§7. Usa !aceptar.`);
        }
    });
}

function showLeaveConfirm(player) {
    new MessageFormData()
        .title("§l§c¿Abandonar Clan?")
        .body("Perderás todos los beneficios.\n¿Estás seguro?")
        .button1("Sí, Abandonar").button2("Cancelar")
        .show(player).then(r => {
            if (r.canceled || r.selection === 0) return;
            system.run(() => {
                const res = ClanManager.removeMember(player.name);
                if (res === "is_leader") player.sendMessage("§c[Nexus] §7Eres líder. Transfiere el rol antes de salir.");
                else if (res) player.sendMessage("§e[Nexus] §7Has abandonado el clan.");
            });
        });
}