import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { Database } from "../core/database.js";
import { UI_STYLE } from "./uiConfig.js";
import { showSocialHub } from "./socialHub.js";
import { ClanBaseManager } from "../core/clanDatabase.js"; // Import necesario

// --- UTILIDAD PARA TAGS ---
function updateClanTag(player, clanName) {
    player.getTags().filter(t => t.startsWith("clan:")).forEach(t => player.removeTag(t));
    if (clanName) player.addTag(`clan:${clanName}`);
}

// Función auxiliar mejorada
function getPlayerClan(playerName) {
    const list = Database.getClanList();
    for (const item of list) {
        const data = Database.getClanData(item.name);
        if (data && data.members.includes(playerName)) return data;
    }
    return null;
}

export function showClanMenu(player) {
    const clan = getPlayerClan(player.name);
    const isLeader = clan && clan.leader === player.name;

    const form = new ActionFormData()
        .title("§l⚔️ GESTIÓN DE CLAN")
        .body(`${UI_STYLE.color.dim}Estado: ${clan ? "§aDentro de un clan" : "§7Sin clan"}\n${UI_STYLE.divider}`);

    if (!clan) {
        form.button("§a§l+ Crear Clan", "textures/ui/color_plus");
    } else {
        form.button("§l👥 Ver Miembros", "textures/ui/group");
        if (isLeader) {
            form.button("§l📍 Gestionar Base", "textures/ui/marker_edit");
        }
        form.button("§c§l🚪 Salir del Clan", "textures/ui/cancel");
    }

    form.button("§7« Volver", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.canceled) return showSocialHub(player);

        if (!clan) {
            if (res.selection === 0) showCreateClanForm(player);
            else showSocialHub(player);
        } else {
            // Lógica de navegación dinámica según el rango
            if (res.selection === 0) { // Miembros
                showMembersMenu(player, clan);
            } else if (isLeader && res.selection === 1) { // Gestionar Base (Solo líder)
                confirmSetBase(player, clan.name);
            } else if ((!isLeader && res.selection === 1) || (isLeader && res.selection === 2)) { // Salir
                confirmLeaveClan(player, clan);
            } else {
                showSocialHub(player);
            }
        }
    });
}

function confirmSetBase(player, clanName) {
    const modal = new ModalFormData()
        .title("§l⚠️ ¿ESTABLECER BASE?")
        .message(`§7Tu base se marcará en:\n§eX: ${Math.floor(player.location.x)} Y: ${Math.floor(player.location.y)} Z: ${Math.floor(player.location.z)}\n\n§c¡Esto sobrescribirá la base anterior si existe!`)
        .toggle("Confirmar actualización de territorio", false);

    modal.show(player).then(res => {
        if (res.canceled || !res.formValues[0]) return showClanMenu(player);

        const success = ClanBaseManager.setClanBase(clanName, player.location);
        
        if (success) {
            player.sendMessage(`§a[Nexus] Base establecida exitosamente en tus coordenadas.`);
            player.dimension.spawnParticle("minecraft:happy_villager", player.location);
        } else {
            player.sendMessage("§c[Nexus] Error al registrar la base.");
        }
        showClanMenu(player);
    });
}

// ... (El resto de tus funciones: showCreateClanForm, confirmLeaveClan, leaveClan, showMembersMenu, showInviteForm permanecen iguales)

function showCreateClanForm(player) {
    if (getPlayerClan(player.name)) {
        player.sendMessage("§c[Nexus] Ya perteneces a un clan.");
        return showClanMenu(player);
    }

    const form = new ModalFormData()
        .title("§l⚔️ CREAR CLAN")
        .textField("Nombre del Clan (3-15 chars):", "Ej: DragonSlayers")
        .textField("Escribe 'CREAR' para confirmar:", "CREAR");

    form.show(player).then(res => {
        if (res.canceled) return showClanMenu(player);
        
        const name = res.formValues[0].trim();
        const confirm = res.formValues[1].trim();

        if (name.length < 3 || name.length > 15) {
            player.sendMessage("§c[Nexus] Nombre inválido.");
            return showCreateClanForm(player);
        }
        
        if (confirm.toUpperCase() !== "CREAR") {
            player.sendMessage("§c[Nexus] Debes escribir 'CREAR' exactamente.");
            return showCreateClanForm(player);
        }
        
        const success = Database.createClan(name, player.name);
        if (success) {
            updateClanTag(player, name);
            player.sendMessage(`§a[Nexus] ¡Clan §e${name} §acreado!`);
            showClanMenu(player);
        } else {
            player.sendMessage("§c[Nexus] Ese nombre ya está ocupado.");
            showCreateClanForm(player);
        }
    });
}

function confirmLeaveClan(player, clan) {
    const form = new ActionFormData()
        .title("§l⚠ SALIR DEL CLAN")
        .body(`¿Estás seguro de que quieres abandonar §e${clan.name}§f?\n\n§7Si eres el único miembro, el clan se borrará permanentemente.`)
        .button("§cSí, abandonar clan")
        .button("§7No, cancelar");

    form.show(player).then(res => {
        if (res.selection === 0) leaveClan(player, clan);
        else showClanMenu(player);
    });
}

function leaveClan(player, clan) {
    const updatedMembers = clan.members.filter(m => m !== player.name);
    
    if (updatedMembers.length === 0) {
        Database.deleteClan(clan.name);
        const list = Database.getClanList().filter(c => c.name !== clan.name);
        Database.saveClanList(list);
    } else {
        clan.members = updatedMembers;
        Database.saveClanData(clan.name, clan);
    }
    
    updateClanTag(player, null);
    player.sendMessage(`§e[Nexus] Has abandonado el clan ${clan.name}.`);
    showClanMenu(player);
}

function showMembersMenu(player, clan) {
    const isLeader = clan.leader === player.name;
    
    const form = new ActionFormData()
        .title(`§l👥 ${clan.name}`)
        .body(`§7Líder: ${clan.leader}\n\n${clan.members.map(m => `§f- ${m}`).join("\n")}\n\n${UI_STYLE.divider}`);

    if (isLeader) {
        form.button("§a§l+ Invitar Jugador", "textures/ui/color_plus");
    }
    form.button("§7« Volver", "textures/ui/arrow_left");
    
    form.show(player).then(res => {
        if (res.canceled) return showClanMenu(player);
        
        if (isLeader && res.selection === 0) {
            return showInviteForm(player, clan);
        }
        
        showClanMenu(player);
    });
}
// --- FUNCIÓN ACTUALIZADA: GESTIÓN DE MIEMBROS INTERACTIVA ---
function showMembersMenu(player, clan) {
    const isLeader = clan.leader === player.name;
    
    const form = new ActionFormData()
        .title(`§l👥 MIEMBROS: ${clan.name}`)
        .body(`§7Líder: ${clan.leader}\n\n${UI_STYLE.divider}`);

    // Creamos un botón por cada miembro para poder hacer clic en ellos
    clan.members.forEach(member => {
        const role = member === clan.leader ? "§6[LÍDER]" : "§7[MIEMBRO]";
        form.button(`${member}\n${role}`, "textures/ui/friend_icon");
    });

    if (isLeader) {
        form.button("§a§l+ Invitar Jugador", "textures/ui/color_plus");
    }
    form.button("§7« Volver", "textures/ui/arrow_left");
    
    form.show(player).then(res => {
        if (res.canceled) return showClanMenu(player);
        
        const memberCount = clan.members.length;
        
        // Si el usuario hizo clic en un miembro (cualquier botón antes de "Invitar" o "Volver")
        if (res.selection < memberCount) {
            const targetName = clan.members[res.selection];
            
            // Solo abrimos opciones si es el líder y NO es él mismo
            if (isLeader && targetName !== player.name) {
                showMemberOptions(player, clan, targetName);
            } else {
                showMembersMenu(player, clan); // Solo ver
            }
        } 
        // Si el líder hizo clic en "Invitar"
        else if (isLeader && res.selection === memberCount) {
            showInviteForm(player, clan);
        } else {
            showClanMenu(player);
        }
    });
}

// --- NUEVA FUNCIÓN: OPCIONES DE GESTIÓN (EXPULSIÓN) ---
function showMemberOptions(player, clan, targetName) {
    const form = new ActionFormData()
        .title(`§l🛠️ GESTIÓN: ${targetName}`)
        .body(`¿Qué deseas hacer con §e${targetName}§f?`)
        .button("§c§lExpulsar del Clan", "textures/ui/cancel")
        .button("§7Volver", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.selection === 0) { // Acción: Expulsar
            const success = Database.kickMember(clan.name, targetName);
            if (success) {
                // Quitamos el tag al jugador si está online para que pierda privilegios al instante
                const targetPlayer = world.getPlayers().find(p => p.name === targetName);
                if (targetPlayer) {
                    targetPlayer.getTags().filter(t => t.startsWith("clan:")).forEach(t => targetPlayer.removeTag(t));
                    targetPlayer.sendMessage(`§c[Nexus] Has sido expulsado del clan ${clan.name}.`);
                }
                player.sendMessage(`§a[Nexus] ${targetName} ha sido expulsado.`);
            } else {
                player.sendMessage("§c[Nexus] Error al expulsar.");
            }
            showMembersMenu(player, clan);
        } else {
            showMembersMenu(player, clan);
        }
    });
}
function showInviteForm(player, clan) {
    const form = new ModalFormData()
        .title("§l📩 INVITAR JUGADOR")
        .textField("Nombre del jugador:", "Ej: Mateo");

    form.show(player).then(res => {
        if (res.canceled) return showMembersMenu(player, clan);
        
        const targetName = res.formValues[0].trim();
        if (!targetName) return showMembersMenu(player, clan);
        
        Database.invitePlayerToClan(player.name, targetName, clan.name);
        player.sendMessage(`§a[Nexus] Invitación enviada a §e${targetName}§f.`);
        showMembersMenu(player, clan);
    });
}