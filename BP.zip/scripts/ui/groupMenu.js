import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { GroupManager } from "../core/groupManager.js"; // Importamos el backend anterior

export function showGroupMenu(player) {
    const isInGroup = player.hasTag("in_group");
    const form = new ActionFormData()
        .title("§l👥 GESTIÓN DE GRUPOS");

    if (!isInGroup) {
        form.button("§l➕ Crear Grupo Nuevo", "textures/ui/color_plus");
    } else {
        form.button("§l👀 Ver Miembros", "textures/ui/friend_glyph_centered");
        form.button("§l✉️ Invitar Jugador", "textures/ui/mail_unopened_hover");
        form.button("§l🚪 Salir del Grupo", "textures/ui/cancel");
    }
    form.button("§l« Volver", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.canceled) return;
        
        if (!isInGroup) {
            if (res.selection === 0) {
                GroupManager.createGroup(player);
                player.sendMessage("§a[Nexus] Grupo creado.");
            }
        } else {
            handleGroupActions(player, res.selection);
        }
    });
}

function handleGroupActions(player, selection) {
    switch (selection) {
        case 0: // Ver Miembros
            const members = GroupManager.getGroupMembers(player);
            player.sendMessage(`§eMiembros: §f${members.join(", ")}`);
            break;
        case 1:
            inviteForm.show(player).then(res => {
                if (res.canceled) return;
                const target = players[res.formValues[0]];
                const groupId = GroupManager.playerGroups.get(player.name); 
                const inviteText = `§l👥 INVITACIÓN AL GRUPO\n§fDe: ${player.name}\n§7ID_GRUPO:${groupId}\n\n§eResponde "ACEPTAR" para unirte.`;
                Database.addMessageToInbox(target.name, "SISTEMA (Grupo)", inviteText);
                
                player.sendMessage(`§a[Nexus] Invitación enviada a ${target.name}`);
            }); a ${target.name}`);
            });
            break;
        case 2: // Salir
            GroupManager.leaveGroup(player);
            player.sendMessage("§c[Nexus] Has abandonado el grupo.");
            break;
    }
}