import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { Database } from "../core/database.js";
import { UI_STYLE } from "./uiConfig.js";
import { showSocialHub } from "./socialHub.js";
import { GroupManager } from "../core/groupManager.js";

const MESSAGES_PER_PAGE = 8;

function updatePlayerClan(player, clanName) {
    player.getTags().filter(tag => tag.startsWith("clan_")).forEach(tag => player.removeTag(tag));
    player.addTag(`clan_${clanName}`);
}

export function showInboxMenu(player, page = 0) {
    Database.cleanupInbox(player.name);
    const inbox = Database.getInbox(player.name);
    const totalPages = Math.ceil(inbox.length / MESSAGES_PER_PAGE) || 1;
    
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;

    const startIndex = page * MESSAGES_PER_PAGE;
    const pageMessages = inbox.slice(startIndex, startIndex + MESSAGES_PER_PAGE);

    const form = new ActionFormData()
        .title(`§l📥 BUZÓN (Pág ${page + 1}/${totalPages})`)
        .body(`${UI_STYLE.color.dim}Total de mensajes: ${inbox.length}\n${UI_STYLE.divider}`);

    pageMessages.forEach((msg) => {
        const icon = msg.read ? "textures/ui/mail_opened" : "textures/ui/mail_unopened_hover";
        const unreadColor = msg.read ? "§7" : "§l§e";
        form.button(`${unreadColor}De: ${msg.sender}\n§r§8${msg.date}`, icon);
    });

    if (page > 0) form.button("§l« Pág Anterior", "textures/ui/arrow_left");
    if (page < totalPages - 1) form.button("§lPág Siguiente »", "textures/ui/arrow_right");
    form.button("§c« VOLVER", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled) return showSocialHub(player);

        const selection = res.selection;
        const totalButtons = pageMessages.length;
        const hasPrev = page > 0;
        const hasNext = page < totalPages - 1;

        if (selection < totalButtons) {
            const realIndex = startIndex + selection;
            readMessage(player, realIndex, inbox[realIndex], page);
        } else if (hasPrev && selection === totalButtons) {
            showInboxMenu(player, page - 1);
        } else if (!hasPrev && hasNext && selection === totalButtons) {
            showInboxMenu(player, page + 1);
        } else if (hasPrev && hasNext && selection === totalButtons + 1) {
            showInboxMenu(player, page + 1);
        } else {
            showSocialHub(player);
        }
    });
}

function readMessage(player, index, msg, page) {
    Database.markMessageAsRead(player.name, index); 
    
    const isClanInvite = msg.text.includes("§l⚔️ INVITACIÓN AL CLAN");
    const isGroupInvite = msg.text.includes("§l👥 INVITACIÓN AL GRUPO");
    const isInvite = isClanInvite || isGroupInvite;

    const form = new ActionFormData()
        .title(`§l✉️ MENSAJE DE: ${msg.sender}`)
        .body(`§7Fecha: §e${msg.date}\n${UI_STYLE.divider}\n\n§f${msg.text}\n\n${UI_STYLE.divider}`);

    // Botón dinámico: Aceptar si es invitación, Responder si es mensaje normal
    if (isInvite) {
        form.button("§a§l✅ ACEPTAR INVITACIÓN", "textures/ui/check");
    } else {
        form.button("§l↪ Responder", "textures/ui/refresh");
    }

    form.button("§l🗑️ Borrar Mensaje", "textures/ui/trash");
    form.button("§l« Volver", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 2) return showInboxMenu(player, page);
        
        if (res.selection === 0) {
            if (isInvite) {
                processInvitation(player, msg, isClanInvite);
            } else {
                openReplyForm(player, msg.sender);
            }
        } else if (res.selection === 1) {
            Database.deleteMessage(player.name, index); 
            player.sendMessage(`${UI_STYLE.color.success}[Nexus] Mensaje eliminado.`);
            showInboxMenu(player, page);
        }
    });
}

function processInvitation(player, msg, isClan) {
    try {
        if (isClan) {
            const clanName = msg.text.split("clan §e")[1].split("§f")[0];
            const success = Database.addMemberToClan(clanName, player.name);
            if (success) {
                updatePlayerClan(player, clanName);
                player.sendMessage(`§a[Nexus] ¡Te has unido al clan §e${clanName}§a!`);
            } else {
                player.sendMessage("§c[Nexus] No se pudo unir al clan.");
            }
        } else {
            const groupId = msg.text.split("ID_GRUPO:")[1].split("\n")[0];
            const success = GroupManager.joinGroup(groupId, player);
            if (success) {
                player.sendMessage(`§a[Nexus] ¡Te has unido al grupo exitosamente!`);
            } else {
                player.sendMessage(`§c[Nexus] El grupo ya no existe.`);
            }
        }
    } catch (e) {
        player.sendMessage("§c[Nexus] Error crítico al procesar la invitación.");
    }
    showInboxMenu(player);
}

function openReplyForm(player, targetName) {
    const form = new ModalFormData()
        .title(`§l↪ RESPONDER A: ${targetName}`)
        .textField("Tu respuesta:", "Escribe aquí...");

    form.show(player).then(res => {
        if (res.canceled || !res.formValues[0]) return;
        const msg = res.formValues[0].trim();

        const targetOnline = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
        if (targetOnline) {
            targetOnline.onScreenDisplay.setTitle("§l§e✉️ NUEVA RESPUESTA", {
                subtitle: `De: ${player.name}`,
                fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10
            });
            targetOnline.runCommandAsync("playsound random.orb @s ~ ~ ~ 1 1");
        }
        
        Database.addMessageToInbox(targetName, player.name, msg);
        player.sendMessage(`§a[Nexus] §7Respuesta enviada a §e${targetName}§f.`);
    });
}