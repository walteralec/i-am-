import { ActionFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showClanMenu } from "./clanMenu.js";
import { showSocialHub } from "./socialHub.js";
import { showTeamMenu } from "../teams/teamMenu.js";
import { showBookMenu } from "./bookMenu.js";

export function showMainHub(player) {
    const form = new ActionFormData()
        .title(UI_STYLE.header)
        .body(`${UI_STYLE.color.dim}Sistema de Gestión Integrada\n${UI_STYLE.divider}`)
        .button("§l🛡️ CLANES\n§r§8Gestión y Territorio", "textures/ui/icon_recipe_equipment")
        .button("§l✉️ SOCIAL\n§r§8Inbox y Perfil", "textures/ui/mail_open_hover")
        .button("§l⚔️ EQUIPO\n§r§8Gestión Temporal", "textures/ui/friendsIcon")
        .button("§l📍 MIS LUGARES\n§r§8Coordenadas Guardadas", "textures/ui/store_home_icon");

    form.show(player).then((response) => {
        if (response.canceled) return;
        
        const actions = [
            () => showClanMenu(player),
            () => showSocialHub(player),
            () => showTeamMenu(player),
            () => showBookMenu(player)
        ];
        
        actions[response.selection]?.();
    });
}