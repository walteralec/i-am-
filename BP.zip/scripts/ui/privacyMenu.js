import { ActionFormData } from "@minecraft/server-ui";
import { Database } from "../core/database.js";
import { UI_STYLE } from "./uiConfig.js";
import { showSocialHub } from "./socialHub.js";

export function showPrivacyMenu(player) {
    const blockedList = Database.getBlockedList(player.name);
    
    const form = new ActionFormData()
        .title("§l🛡️ PRIVACIDAD")
        .body(`${UI_STYLE.color.dim}Gestiona a tus jugadores bloqueados:\n${UI_STYLE.divider}`);

    if (blockedList.length === 0) {
        form.body("§7No tienes a nadie bloqueado actualmente.");
    } else {
        blockedList.forEach((name) => {
            form.button(`§c§l× §r${name}`, "textures/ui/cancel");
        });
    }
    
    form.button("§l« VOLVER", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.canceled || res.selection === blockedList.length) return showSocialHub(player);
        
        // Si seleccionó a alguien, lo desbloqueamos
        const targetToUnblock = blockedList[res.selection];
        Database.unblockPlayer(player.name, targetToUnblock);
        
        player.sendMessage(`§a[Nexus] §7Has desbloqueado a §e${targetToUnblock}§f.`);
        try { player.runCommandAsync("playsound random.levelup @s ~ ~ ~ 1 0.5"); } catch(e){}
        
        // Refrescamos el menú
        showPrivacyMenu(player);
    });
}