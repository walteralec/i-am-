import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainHub } from "./mainHub.js";
import { showInboxMenu } from "./inboxMenu.js";
import { showPrivacyMenu } from "./privacyMenu.js"; // Importamos el nuevo menú
import { Database } from "../core/database.js";

export function showSocialHub(player) {
    // Calculamos mensajes no leídos para el botón
    const inbox = Database.getInbox(player.name);
    const unreadCount = inbox.filter(m => !m.read).length;
    const inboxText = unreadCount > 0 
        ? `§l📥 Buzón (§e${unreadCount} nuevos§f)` 
        : "§l📥 Buzón de Entrada";

    const form = new ActionFormData()
        .title(`§l✉️ NEXUS SOCIAL`)
        .body(`${UI_STYLE.color.dim}Inbox y Comunicaciones\n${UI_STYLE.divider}`)
        .button(inboxText, "textures/ui/mail_unopened")          // 0
        .button("§l👤 Mensaje Privado", "textures/ui/generic_person") // 1
        .button("§l🛡️ Chat de Clan", "textures/ui/icon_recipe_equipment") // 2
        .button("§l⚔️ Chat de Equipo", "textures/ui/friendsIcon")    // 3
        .button("§l🔐 Privacidad", "textures/ui/lock")              // 4 - NUEVO BOTÓN
        .button("§c« VOLVER AL HUB", "textures/ui/cancel");         // 5

    form.show(player).then((response) => {
        if (response.canceled) return showMainHub(player);

        switch (response.selection) {
            case 0: showInboxMenu(player); break;
            case 1: openPrivateChat(player); break;
            case 2: openGroupChat(player, "Clan"); break;
            case 3: openGroupChat(player, "Equipo"); break;
            case 4: showPrivacyMenu(player); break; // Abrir Privacidad
            case 5: showMainHub(player); break;
        }
    });
}

function openPrivateChat(player) {
    const form = new ModalFormData()
        .title("§l👤 CHAT PRIVADO")
        .textField("Nombre del jugador:\n(Se guardará en buzón si está offline)", "Ej: Mateo")
        .textField("Escribe tu mensaje:", "Hola...");

    form.show(player).then((response) => {
        if (response.canceled) return showSocialHub(player);
        
        const targetName = response.formValues[0].trim();
        const msg = response.formValues[1].trim();
        
        if (!targetName || !msg) return showSocialHub(player);

        // Verificamos si el destinatario te tiene bloqueado
        if (Database.isBlocked(targetName, player.name)) {
            player.sendMessage(`§c[Nexus] No puedes enviarle mensajes a ${targetName} porque te tiene bloqueado.`);
            return showSocialHub(player);
        }

        const targetOnline = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());

        if (targetOnline) {
            // --- ENVÍO EN VIVO + NOTIFICACIÓN VISUAL ---
            targetOnline.sendMessage(`§8[§d${player.name} §8-> §dMí§8] §f${msg}`);
            
            targetOnline.onScreenDisplay.setTitle("§l§e✉️ NUEVO MENSAJE", {
                subtitle: `De: ${player.name}`,
                fadeInDuration: 10,
                stayDuration: 60,
                fadeOutDuration: 10
            });
            targetOnline.runCommandAsync("playsound random.orb @s ~ ~ ~ 1 1");
            
            player.sendMessage(`${UI_STYLE.color.success}[Nexus] Mensaje enviado a §e${targetOnline.name}§f: ${msg}`);
        } else {
            // --- ENVÍO AL BUZÓN (OFFLINE) ---
            Database.addMessageToInbox(targetName, player.name, msg);
            player.sendMessage(`§a[Nexus] §e${targetName} §7no está conectado. Tu mensaje se ha guardado en su buzón.`);
            try { player.runCommandAsync("playsound random.levelup @s ~ ~ ~ 1 1.5"); } catch(e){}
        }
        
        showSocialHub(player);
    });
}

function openGroupChat(player, type) {
    const form = new ModalFormData()
        .title(`§l💬 CHAT DE ${type.toUpperCase()}`)
        .textField(`Enviar mensaje a tu ${type}:`, "Escribe aquí...");

    form.show(player).then((response) => {
        if (response.canceled) return showSocialHub(player);
        
        const msg = response.formValues[0];
        if (!msg) return showSocialHub(player);

        player.sendMessage(`${UI_STYLE.color.success}[Nexus] ${UI_STYLE.color.text}Mensaje de ${type} enviado: ${msg}`);
        showSocialHub(player);
    });
}