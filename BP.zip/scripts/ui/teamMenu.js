import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainHub } from "./mainHub.js";
import { GroupManager } from "../core/groupManager.js";
import { Database } from "../core/database.js";
import { world } from "@minecraft/server";

export function showTeamMenu(player) {
    const isInGroup = GroupManager.isPlayerInGroup(player);
    const members = GroupManager.getGroupMembers(player);

    const form = new ActionFormData()
        .title(`§l⚔️ GESTIÓN DE EQUIPO`)
        .body(`${UI_STYLE.color.dim}Estado: ${isInGroup ? "§aDentro de un Grupo" : "§7Sin Grupo"}\n${isInGroup ? `§7Miembros (${members.length}): §f${members.join(", ")}` : ""}\n${UI_STYLE.divider}`)
        .button(isInGroup ? "§l➕ Invitar a un Jugador" : "§l➕ Crear Grupo", "textures/ui/color_plus")
        .button("§l🏃 Abandonar Grupo", "textures/ui/icon_trash")
        .button("§c« VOLVER AL HUB", "textures/ui/cancel");

    form.show(player).then((response) => {
        if (response.canceled) return showMainHub(player);

        switch (response.selection) {
            case 0:
                if (!isInGroup) {
                    GroupManager.createGroup(player);
                    player.sendMessage(`§a[Nexus] ¡Grupo creado exitosamente!`);
                    showTeamMenu(player);
                } else {
                    inviteTeamMember(player);
                }
                break;
            case 1:
                if (isInGroup) {
                    confirmLeaveGroup(player);
                } else {
                    player.sendMessage("§c[Nexus] No estás en ningún grupo.");
                    showTeamMenu(player);
                }
                break;
            case 2:
                showMainHub(player);
                break;
        }
    });
}

// Función de confirmación para no salir por error
function confirmLeaveGroup(player) {
    const form = new ActionFormData()
        .title("§l⚠️ ¿ABANDONAR?")
        .body("¿Estás seguro de que deseas salir del grupo?\n§7Si eres el único, el grupo se eliminará.")
        .button("§cSí, abandonar")
        .button("§7No, cancelar");

    form.show(player).then(res => {
        if (res.selection === 0) {
            GroupManager.leaveGroup(player);
            player.sendMessage(`${UI_STYLE.color.warn}[Nexus] ${UI_STYLE.color.text}Has abandonado el grupo.`);
        }
        showTeamMenu(player);
    });
}

function inviteTeamMember(player) {
    const form = new ModalFormData()
        .title("§l⚔️ NUEVO INTEGRANTE")
        .textField("Nombre del jugador a invitar:", "Ej: Tomás");

    form.show(player).then((response) => {
        if (response.canceled) return showTeamMenu(player);
        
        const targetName = response.formValues[0].trim();
        if (!targetName) return showTeamMenu(player);

        // Validación 1: No invitarse a uno mismo
        if (targetName.toLowerCase() === player.name.toLowerCase()) {
            player.sendMessage("§c[Nexus] ¡No puedes invitarte a ti mismo!");
            return showTeamMenu(player);
        }

        // Validación 2: Jugador online
        const targetPlayer = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
        if (!targetPlayer) {
            player.sendMessage("§c[Nexus] Ese jugador no está conectado.");
            return showTeamMenu(player);
        }

        // Envío al buzón
        const groupId = GroupManager.getGroupId(player);
        const inviteText = `§l👥 INVITACIÓN AL GRUPO\nEl jugador §e${player.name} §fte invita a su grupo.\n\nID_GRUPO:${groupId}\n\n§7Responde 'ACEPTAR' para unirte.`;
        
        Database.addMessageToInbox(targetName, player.name, inviteText);
        player.sendMessage(`${UI_STYLE.color.success}[Nexus] Invitación enviada a §e${targetName}§f.`);
    });
}