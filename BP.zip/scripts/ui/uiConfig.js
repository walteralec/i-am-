export const UI_STYLE = {
    header: "§l§6NEXUS §fHUB",
    divider: "§8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
    color: {
        brand: "§6",
        text: "§f",
        dim: "§7",
        warn: "§c",
        success: "§a"
    }
};