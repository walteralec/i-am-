// Funciones repetitivas (ej: botón 'Volver')
