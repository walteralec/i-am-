import mysql.connector

def conectar():
    return mysql.connector.connect(
        host="tu_host",
        user="tu_usuario",
        password="tu_password",
        database="tu_bd"
    )

def listar_libros():
    db = conectar()
    cur = db.cursor()
    cur.execute("SELECT id, titulo, autor FROM libros")
    for x in cur.fetchall():
        print(x)
    db.close()

def agregar_libro():
    titulo = input("Título: ")
    autor = input("Autor: ")
    db = conectar()
    cur = db.cursor()
    cur.execute("INSERT INTO libros (titulo, autor) VALUES (%s, %s)", (titulo, autor))
    db.commit()
    db.close()

def menu():
    while True:
        print("=== Sistema de Gestión de Biblioteca ===")
        print("1. Listar libros")
        print("2. Agregar libro")
        print("0. Salir")
        op = input("Opción: ")
        if op == "1":
            listar_libros()
        elif op == "2":
            agregar_libro()
        elif op == "0":
            break

menu()